# IPOO Trabajo Final Entregable
 Trabajo Final Entregable de Introducción Orientada a Objetos

## Integrantes GRUPO 8
Velo, Carlos Rodrigo
FAI-5106
carlos.velo@est.fi.uncoma.edu.ar

Celayes, Brisa Abril
FAI-4923
brisa.celayes@est.fi.uncoma.edu.ar

De La Iglesia, Alberto Martin 
FAI-5084
alberto.delaiglesia@est.fi.uncoma.edu.ar

### LINK GITHUB

https://github.com/abrilbc/IPOO-Trabajo-Final-Entregable.git

